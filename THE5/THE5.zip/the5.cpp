#include "the5.h"

/* 
    in the5.h "struct Room" is defined as below:
    
    struct Room {
        int id;
        char content;
        vector<Room*> neighbors;
    };

*/


vector<int> maze_trace(vector<Room*> maze) { 

    vector<int> path;
    
    //your code here
    

    return path; // this is a dummy return value. YOU SHOULD CHANGE THIS!
}


